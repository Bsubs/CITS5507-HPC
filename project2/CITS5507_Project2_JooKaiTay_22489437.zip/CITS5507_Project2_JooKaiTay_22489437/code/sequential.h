#ifndef SEQ_H
#define SEQ_H
#include "fish.h"

/**
 * Author: Joo Kai TAY (22489437)
*/

void sequential(Fish* fishArray, int numfish, int numsteps);

#endif